function test() {
  {;}
  ;
  "test";
  {
    "1";
    if (true) {
      "2";
    }
    ;
    {
      "3";
      if ("test") {
        "5";
      }
    }
    "4";
  }
}
