## Overview

Example to demonstrate PDF.js library usage with a viewer optimized for mobile usage.

## Getting started

Build PDF.js using `gulp dist-install` and run `gulp server` to start a web server.
You can then work with the mobile viewer at
http://localhost:8888/examples/mobile-viewer/viewer.html.

Refer to `viewer.js` for the source code of the mobile viewer.
