import React from 'react';

import Pdf from './pdf';

export default function App () {
  return (
    <main>
      <h1>PDF.js rendering example with Create React App</h1>
      <Pdf />
    </main>
  )
}